# Bible BFF ✦ — AI-Powered Bible Study App

> *"I never knew how much tea was in the Bible until I listened to Bible BFF"*

A modern, conversational Bible study web app — inspired by the [@biblebff](https://www.tiktok.com/@biblebff) TikTok trend. Turns any Bible verse or story into an engaging, relatable experience narrated by an AI "bestie."

---

## ✨ Features

| Tab | What it does |
|---|---|
| 🏠 **Home** | Daily devotional, streak tracker, quick-start grid |
| 📖 **Stories** | 12 Bible stories with context + AI narration |
| 💛 **Feeling** | Find a verse based on how you feel right now |
| 💬 **Chat** | Ask your Bible BFF anything — gets scripture-based answers |
| ☕ **Tea** | Spill the tea on any verse in 7 styles (BFF, Pastor, Drama, TikTok…) |
| 🙏 **Prayer** | Prayer journal — track requests & mark answered |
| 📋 **Plan** | 9 reading plans (7-day, 14-day, 30-day) with progress tracking |
| 🔍 **Search** | Search any Bible verse by reference |
| 💾 **Saved** | Favorites + reading history |

---

## 🚀 Deploy to GitHub Pages (free)

### 1. Fork or create repo

```bash
git init bible-bff
cd bible-bff
# copy index.html into this folder
git add .
git commit -m "initial commit"
git remote add origin https://github.com/YOUR_USERNAME/bible-bff.git
git push -u origin main
```

### 2. Enable GitHub Pages

1. Go to your repo on GitHub
2. Click **Settings** → **Pages**
3. Under *Source*, select **Deploy from a branch**
4. Choose `main` branch, `/ (root)` folder
5. Click **Save**

Your app will be live at:
```
https://YOUR_USERNAME.github.io/bible-bff/
```

### 3. Add your API key (in the app)

The AI features (Chat, Tea, Feeling, Stories) need an Anthropic API key.

1. Get a free key at [console.anthropic.com](https://console.anthropic.com)
2. Open the app → tap **⚙** (settings gear, bottom right)
3. Paste your key in the **Anthropic API Key** field
4. Tap **Save**

The key is stored in your browser's `localStorage` — it never leaves your device.

> **Note:** If you want to share the app publicly without exposing your key, see [Adding a backend](#adding-a-backend) below.

---

## 📋 Reading Plans Included

**7-Day Plans**
- 🌟 7 Days of Hope
- 🕊️ Let Go of Anxiety
- 🪨 Unshakeable Faith
- 👑 Women of the Bible
- 🌿 Healing & Restoration
- 💎 Know Who You Are

**14-Day Plans**
- ❤️ The Love Chapter (1 Corinthians 13)

**30-Day Plans**
- 📜 30 Days in the Psalms
- ✝️ 30 Days with Jesus

---

## 📖 Bible Versions

KJV · WEB · BBE · WEBBE · OEB (US) · OEB (Commonwealth) · Clementine Latin · Almeida (Portuguese) · RCCV (Romanian)

Verses fetched live from [bible-api.com](https://bible-api.com) — free, no key needed.

---

## 🛠 Tech Stack

- **Pure HTML/CSS/JS** — no frameworks, no build step
- **Web Speech API** — browser-native text-to-speech narration
- **Anthropic Claude API** — AI rewriting, chat, devotionals
- **bible-api.com** — free Bible verse API
- **localStorage** — streak, favorites, prayer journal, reading progress

---

## 🗂 File Structure

```
bible-bff/
├── index.html        ← The entire app (single file)
├── README.md         ← This file
├── .gitignore        ← Ignores sensitive files
└── LICENSE           ← MIT License
```

Everything is in one `index.html` — easy to deploy anywhere.

---

## Adding a Backend

To share the app publicly without exposing an API key, you can add a small serverless proxy. Example with **Vercel Edge Functions**:

```js
// api/claude.js (Vercel)
export default async function handler(req) {
  const body = await req.json();
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': process.env.ANTHROPIC_API_KEY,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify(body),
  });
  return new Response(await res.text(), {
    headers: { 'Content-Type': 'application/json' },
  });
}

export const config = { runtime: 'edge' };
```

Then change `callAI()` in the app to hit `/api/claude` instead of `api.anthropic.com` directly.

---

## 📸 Screenshots

| Home | Stories | Tea ☕ |
|---|---|---|
| Daily devotional + streak | Context + AI narration | Any verse, any style |

---

## 🙏 Credits

- Inspired by [@biblebff on TikTok](https://www.tiktok.com/@biblebff)
- Bible data from [bible-api.com](https://bible-api.com)
- AI powered by [Anthropic Claude](https://anthropic.com)
- Built with vibe coding ✨

---

## 📄 License

MIT — free to use, share, and build on.
